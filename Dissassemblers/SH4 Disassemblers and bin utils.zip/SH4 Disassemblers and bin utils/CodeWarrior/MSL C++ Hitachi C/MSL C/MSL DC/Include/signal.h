/*  Metrowerks Standard Library  */

/*  $Date: 1999/01/22 23:40:30 $ 
 *  $Revision: 1.7 $ 
 *  $NoKeywords: $ 
 *
 *		Copyright � 1995-1999 Metrowerks, Inc.
 *		All rights reserved.
 */

/*
 *	signal.h
 */
 
#ifndef _SIGNAL_H
#define _SIGNAL_H

#endif

/*  Changes
 *  ad   990222	Include the O/S specific header rather than MSL
 */