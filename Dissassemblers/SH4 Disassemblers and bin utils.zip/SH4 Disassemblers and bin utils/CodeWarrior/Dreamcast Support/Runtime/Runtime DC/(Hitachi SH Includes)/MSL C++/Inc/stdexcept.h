/*  Metrowerks Standard Library  Version 4.0  1998 August 10  */

/*  $Date:: 3/10/98 8:29 PM                                  $ 
 *  $Revision:: 2                                            $ 
 *  $NoKeywords: $ 
 *
 *		Copyright � 1995-1998 Metrowerks, Inc.
 *		All rights reserved.
 */

/*
 *	stdexcept.h
 */

#ifndef _STDEXCEPT_H
#define _STDEXCEPT_H

#include <stdexcept>

#ifdef MSIPL_USING_NAMESPACE
	using namespace std;
#endif

#endif

/*     Change record
hh 971206  File created.
*/
