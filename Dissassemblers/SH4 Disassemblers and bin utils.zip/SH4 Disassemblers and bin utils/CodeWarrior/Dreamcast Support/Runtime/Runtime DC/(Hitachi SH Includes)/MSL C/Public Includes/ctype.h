/*  Metrowerks Standard Library  Version 4.0  1998 August 10  */

/*  $Date:: 6/5/98 2:32 PM                                   $ 
 *  $Revision:: 14                                           $ 
 *  $NoKeywords: $ 
 *
 *		Copyright � 1995-1998 Metrowerks, Inc.
 *		All rights reserved.
 */

/*
 *	ctype.h
*/

#ifndef _CTYPE_H
#define _CTYPE_H

#include <cctype>

#if defined(__cplusplus) && defined(_MSL_USING_NAMESPACE)
	using namespace std;
#endif

#endif

/*
 * Change record
 * hh 971206 Created.
*/
