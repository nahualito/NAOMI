/*  Metrowerks Standard Library  Version 4.0  1998 August 10  */

/*  $Date:: 6/5/98 2:33 PM                                   $ 
 *  $Revision:: 11                                           $ 
 *  $NoKeywords: $ 
 *
 *		Copyright � 1995-1998 Metrowerks, Inc.
 *		All rights reserved.
 */

/*
 *	stddef.h
*/

#ifndef _STDDEF_H
#define _STDDEF_H

#include <cstddef>

#if defined(__cplusplus) && defined(_MSL_USING_NAMESPACE)
	using namespace std;
#endif

#endif

/*
 * Change record
 * hh 971206 Created.
*/
