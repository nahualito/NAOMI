/*  Metrowerks Standard Library  Version 4.0  1998 August 10  */

/*  $Date:: 6/5/98 2:33 PM                                   $ 
 *  $Revision:: 14                                           $ 
 *  $NoKeywords: $ 
 *
 *		Copyright � 1995-1998 Metrowerks, Inc.
 *		All rights reserved.
 */

/*
 *	inttypes.h
*/

#ifndef _INTTYPES_H
#define _INTTYPES_H

#include <cinttypes>

#if defined(__cplusplus) && defined(_MSL_USING_NAMESPACE)
	using namespace std;
#endif

#endif

/*
 * Change record
 *mm 980724   Created.
*/
