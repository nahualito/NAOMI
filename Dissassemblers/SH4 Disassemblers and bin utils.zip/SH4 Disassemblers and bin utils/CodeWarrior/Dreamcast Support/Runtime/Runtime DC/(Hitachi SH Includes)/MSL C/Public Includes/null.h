/*  Metrowerks Standard Library  Version 4.0  1998 August 10  */

/*  $Date:: 6/5/98 2:33 PM                                   $ 
 *  $Revision:: 10                                           $ 
 *  $NoKeywords: $ 
 *
 *		Copyright � 1995-1998 Metrowerks, Inc.
 *		All rights reserved.
 */

/*
 *	null.h
 */
 
#ifndef NULL

#include <ansi_parms.h>                 /* mm 970905*/

#define NULL	0L

#endif /* ndef NULL */

/*     Change record
 * mm 970905  added include of ansi_parms.h to avoid need for prefix file
 */
