/* mw_write.c */

void write(int iFileNo, char* pBuf, int uiCount);

void write(int iFileNo, char* pBuf, int uiCount)
{
	SN_comms_break();
	return;
}
