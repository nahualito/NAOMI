/* mw_util.h */

void mw_pr(const char *s);